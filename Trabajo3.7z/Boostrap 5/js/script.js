console.log("Entramos");
var items = document.getElementsByClassName("item");
var cantidad=items.length;
console.log(cantidad);

console.log("Cantidad de listas " + cantidad)
var div=document.createElement("div");
div;

div.innerText="Aprendiendo javascript";
var divuno=document.getElementById("uno");
divuno.appendChild(div);
var lista=document.getElementById("lista");
var hijo=document.createElement("li");
hijo.innerText="li nuevo";
lista.appendChild(hijo);

document.getElementById("tres").style.color="red";
document.getElementById("lista").style.color="green";

document.body.style.backgroundColor ="blue";

var divdos=document.createElement("div");
divdos.style.backgroundColor="blue";
var parrafo=document.createElement("p");
parrafo.innerText="Un texto es un conjunto de enunciados que transmiten un mensaje ordenado y coherente, cuya extensión puede variar. Existen diferentes tipos de textos de acuerdo a su estructura y función comunicativa: textos literarios, textos científicos, textos explicativos, textos persuasivos, textos argumentativos.";
var lista2=document.createElement("ul");
var contenido=document.createElement("li");
contenido.innerText="Contenido";
lista2.appendChild(contenido);
divdos.appendChild(parrafo);
divdos.appendChild(lista2);


